<?php
return array(
	//'配置项'=>'配置值'
    'URL_MODEL' => '2',
    'DEFAULT_FILTER'        =>  'strip_tags,addslashes,htmlspecialchars',
);