<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {

    public function index(){
        $this->display();
    }

    public function about(){
        $this->display();
    }

    public function contact(){
        $this->display();
    }

    public function portfolio(){
        $this->display();
    }

    public function services(){
        $this->display();
    }

    public function shortcodes(){
        $this->display();
    }

    public function single(){
        $this->display();
    }
}